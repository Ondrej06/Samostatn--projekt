# Bullet class
