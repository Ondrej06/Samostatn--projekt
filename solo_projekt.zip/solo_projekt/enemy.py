# Enemy class
