import pygame
import sys
import random
import math

pygame.init()

# Okno
WIDTH, HEIGHT = 1280, 720
window = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Bullet Heaven")

# Barvy
BLACK = (0, 0, 0)
RED = (255, 0, 0)

# Hráč
player_img = pygame.image.load("assets/gragas.png")
player_img = pygame.transform.scale(player_img, (50, 50))
player_rect = player_img.get_rect(center=(WIDTH//2, HEIGHT//2))
player_speed = 5
health = 100

# Střely
bullet_img = pygame.image.load("assets/pivo.png")
bullet_img = pygame.transform.scale(bullet_img, (10, 10))
bullets = []
bullet_speed = 10
shoot_cooldown = 120  # každé 2 sekundy při 60 FPS
shoot_timer = 0

# Nepřátelé
enemies = []
enemy_img = pygame.image.load("assets/cat.png")
enemy_img = pygame.transform.scale(enemy_img, (40, 40))
enemy_spawn_timer = 0

# XP
xp_img = pygame.image.load("assets/xp.png")
xp_img = pygame.transform.scale(xp_img, (30, 30))
xp_points = 0
xp_list = []
xp_needed = 2
level = 1
max_level = 25

#food
food_img = pygame.image.load("assets/pizza.png") or pygame.image.load("assets/kebab.png")
food_img = pygame.transform.scale(food_img, (30, 30))
food_list = []

clock = pygame.time.Clock()

running = True
while running:
    clock.tick(60)
    window.fill(BLACK)

    # Události
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Pohyb hráče
    keys = pygame.key.get_pressed()
    dx, dy = 0, 0
    if keys[pygame.K_w]:
        dy -= 1
    if keys[pygame.K_s]:
        dy += 1
    if keys[pygame.K_a]:
        dx -= 1
    if keys[pygame.K_d]:
        dx += 1
    if keys[pygame.K_ESCAPE]:
        running = False
    # Normalizace diagonálního pohybu
    if dx != 0 or dy != 0:
        dist = math.hypot(dx, dy)
        dx = dx / dist
        dy = dy / dist

    player_rect.x += dx * player_speed
    player_rect.y += dy * player_speed

    player_rect.x = max(0, min(WIDTH - player_rect.width, player_rect.x))
    player_rect.y = max(0, min(HEIGHT - player_rect.height, player_rect.y))

    # Automatické střílení
    shoot_timer += 1
    if shoot_timer >= shoot_cooldown:
        mouse_x, mouse_y = pygame.mouse.get_pos()
        dx = mouse_x - player_rect.centerx
        dy = mouse_y - player_rect.centery
        angle_to_mouse = math.atan2(dy, dx)

        # Počet střel dopředu
        num_bullets = 1 + (level - 1)  # začíná 1 střelou na level 1 POTŘEBUJE OPRAVIT !!!!!

        spread = math.pi / num_bullets  # úhel rozprostření všech střel
        for i in range(num_bullets):
            offset = spread * (i - (num_bullets - 1)/2)
            bullets.append([player_rect.centerx, player_rect.centery, angle_to_mouse + offset])

        for i in range(num_bullets):
            offset = spread * (i - (num_bullets - 1)/2)
            bullets.append([player_rect.centerx, player_rect.centery, angle_to_mouse + offset])
            bullets.append([player_rect.centerx, player_rect.centery, angle_to_mouse + offset + math.pi])

        shoot_timer = 0

    # Pohyb střel
    for bullet in bullets[:]:
        bullet[0] += math.cos(bullet[2]) * bullet_speed
        bullet[1] += math.sin(bullet[2]) * bullet_speed
        if bullet[0] < 0 or bullet[0] > WIDTH or bullet[1] < 0 or bullet[1] > HEIGHT:
            bullets.remove(bullet)


    # Spawn jídla
    if random.randint(1, 100) <= 5:  # 5% šance na spawn
        food_list.append([random.randint(0, WIDTH), random.randint(0, HEIGHT)])

    # Spawn nepřátel
    enemy_spawn_timer += 1
    if enemy_spawn_timer >= 60:
        x = random.randint(0, WIDTH)
        y = random.randint(0, HEIGHT)
        enemies.append([x, y])
        enemy_spawn_timer = 0

    # Pohyb nepřátel
    for enemy in enemies:
        dx = player_rect.centerx - enemy[0]
        dy = player_rect.centery - enemy[1]
        dist = math.hypot(dx, dy)
        if dist != 0:
            dx /= dist
            dy /= dist
        enemy[0] += dx * 2
        enemy[1] += dy * 2

    # Kolize střel a nepřátel + XP
    for bullet in bullets[:]:
        for enemy in enemies[:]:
            if pygame.Rect(enemy[0]-20, enemy[1]-20, 40, 40).collidepoint(bullet[0], bullet[1]):
                bullets.remove(bullet)
                enemies.remove(enemy)
                xp_list.append([enemy[0], enemy[1]])
                break

    # Kolize hráče a nepřátel
    for enemy in enemies:
        enemy_rect = pygame.Rect(enemy[0]-20, enemy[1]-20, 40, 40)
        if player_rect.colliderect(enemy_rect):
            health -= 1


    # Sbírání XP hráčem
    for point in xp_list[:]:
        if player_rect.collidepoint(point[0], point[1]):
            xp_points += 1
            xp_list.remove(point)

    # Level up
    while xp_points >= xp_needed and level <= max_level:
        level += 1
        xp_points -= xp_needed  # zbytek XP se přenáší
        xp_needed = int(xp_needed * 2)  # zvyšujeme potřebné XP o 100%
    
    background = pygame.image.load("assets/background1.png").convert()
    background = pygame.transform.scale(background, (WIDTH, HEIGHT))  # volitelné, aby vyplnil okno

    # v hlavní smyčce místo window.fill(...)
    window.blit(background, (0, 0))


    # Vykreslení objektů
    window.blit(player_img, player_rect)
    for bullet in bullets:
        window.blit(bullet_img, (bullet[0]-5, bullet[1]-5))
    for enemy in enemies:
        window.blit(enemy_img, (enemy[0]-20, enemy[1]-20))
    for point in xp_list:
        window.blit(xp_img, (point[0]-15, point[1]-15))

    # Text
    font = pygame.font.SysFont(None, 36)
    xp_text = font.render(f"XP: {xp_points}/{xp_needed}", True, (255, 255, 255))
    level_text = font.render(f"Level: {level}", True, (255, 255, 255))
    #health_text = font.render(f"Health: {health}", True, (255, 255, 255))
    window.blit(xp_text, (10, 10))
    window.blit(level_text, (10, 50))
    #window.blit(health_text, (10, 90))

    # Health bar
    bar_x = 10
    bar_y = 90
    bar_width = 200
    bar_height = 25

    # Červený pozadí = ztracené zdraví
    pygame.draw.rect(window, (255, 0, 0), (bar_x, bar_y, bar_width, bar_height))

    # Zelená část = aktuální zdraví
    current_width = int(bar_width * (health / 100))  # předpokládáme max health = 100
    pygame.draw.rect(window, (0, 255, 0), (bar_x, bar_y, current_width, bar_height))

    # Rámeček kolem
    pygame.draw.rect(window, (255, 255, 255), (bar_x, bar_y, bar_width, bar_height), 2)

    pygame.display.flip()
    if health <= 0:
            running = False
    
pygame.quit()
sys.exit()